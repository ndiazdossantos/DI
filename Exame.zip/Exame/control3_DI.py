import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk


class Exame(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Control 17-12-2020")
        self.set_border_width(10)

        self.solapas = Gtk.Notebook()
        self.add(self.solapas)

        paxina1 = Gtk.Box()
        paxina1.set_border_width(10)


        caixaPrincipal = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        #self.add(caixaPrincipal)

        caixaV1 = Gtk.Box(orientation = Gtk.Orientation.VERTICAL, spacing=2)
        caixaPrincipal.pack_start(caixaV1, False, False, 2)

        caixaH1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        caixaV1.pack_start(caixaH1, False, False, 2)

        boxV1= Gtk.Box(orientation = Gtk.Orientation.VERTICAL, spacing=2)
        contedorH2 = Gtk.Frame()
        lblTitulo = Gtk.Label(label="Configuración zoa de rego")
        lblActivada = Gtk.Label(label="Activada")
        lblHoraComezo = Gtk.Label(label="Hora de comezo")
        lblDuracionRego = Gtk.Label(label="Duración do Rego")
        caixaH1.pack_start(boxV1, False, False, 2)
        boxV1.pack_start(contedorH2, False, False, 2)
        boxV1.pack_start(lblTitulo, False, False, 2)
        boxV1.pack_start(lblActivada, False, False, 2)
        boxV1.pack_start(lblHoraComezo, False, False, 2)
        boxV1.pack_start(lblDuracionRego, False, False, 2)

        boxV2 = Gtk.Box(orientation = Gtk.Orientation.VERTICAL, spacing=2)
        self.swtActivada = Gtk.Switch()
        txtHoraComezo = Gtk.Entry()
        self.cmbDuracionRego = Gtk.ComboBoxText()
        self.cmbDuracionRego.set_size_request(140, 10)
        self.cmbDuracionRego.append_text("5min")
        self.cmbDuracionRego.append_text("10min")
        self.cmbDuracionRego.append_text("20min")
        self.cmbDuracionRego.append_text("30min")
        self.cmbDuracionRego.append_text("60min")
        caixaH1.pack_start(boxV2, False, False, 2)
        boxV2.pack_start(self.swtActivada, False, False, 2)
        boxV2.pack_start(txtHoraComezo, False, False, 2)
        boxV2.pack_start(self.cmbDuracionRego, False, False, 2)
        self.cmbDuracionRego.connect("changed", self.on_btnMostrar_clicked)
        self.swtActivada.connect("state-set", self.on_Activo_clicked)

        caixaH2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        frmOpcions = Gtk.Frame(label="Opcións")
        chkAntixiada = Gtk.CheckButton(label="Antixiada")
        chkDiario = Gtk.CheckButton(label="Diario")
        chkChuvia = Gtk.CheckButton(label="Chuvia")
        caixaV1.pack_start(caixaH2, False, False, 2)
        caixaH2.pack_start(frmOpcions, False, False, 2)
        caixaH2.pack_start(chkAntixiada, False, False, 2)
        caixaH2.pack_start(chkDiario, False, False, 2)
        caixaH2.pack_start(chkChuvia, False, False, 2)
       # self.chkDiario.connect("toggled", self.on_Select_cliked)


        caixaV2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        caixaPrincipal.pack_start(caixaV2, False, False, 2)


        builder = Gtk.Builder()
        builder.add_from_file("./cadroDiasGlade.glade")
        caixaH3 = builder.get_object("frame1")
        self.chkLuns = builder.get_object("Luns")
        caixaV2.add(caixaH3)
        caixaV2.pack_start(caixaH3, False, False, 2)
     #   sinais = {"on_Activo_clicked": self.on_Activo_clicked}
     #   builder.connect_signals(sinais)

        caixaH4 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        btnAceptar = Gtk.Button(label="Aceptar")
        caixaV2.pack_start(caixaH4, False, False, 2)
        caixaH4.pack_start(btnAceptar, False, False, 2)

        self.solapas.append_page(caixaPrincipal, Gtk.Label (label="Zoa 1"))

        paxina2 = Gtk.Box()
        paxina2.set_border_width(10)

        paxina2 = Gtk.Box()
        paxina2.set_border_width(10)
        paxina2.add(Gtk.Label(label="Páxina con unha imaxe e título"))
        self.solapas.append_page(
            paxina2,
            Gtk.Label(label="Zoa2")
        )

        paxina3 = Gtk.Box()
        paxina3.set_border_width(10)

        caixaConsola= Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.tvwTaboa = Gtk.TextView()
        self.tvwTaboa.set_size_request(420, 300)

        self.solapas.append_page(caixaConsola, Gtk.Label(label="Consola"))
        caixaConsola.pack_start(self.tvwTaboa, False, False, 2)



        self.connect("delete-event", Gtk.main_quit)
        self.show_all()

        self.numero = 1

    def on_btnMostrar_clicked(self, boton):
        buffer = self.tvwTaboa.get_buffer()
        nome = self.cmbDuracionRego.get_active_text()
        buffer.insert_at_cursor(nome + "\n")

    def on_Activo_clicked(self, boton, estado ):

        print(self.swtActivada.get_state())
        self.cmbDuracionRego.set_sensitive(estado)

   # def on_Select_cliked(self, boton, estado):
    #     self.chkLuns.set_sensitive(estado)



if __name__ == "__main__":
    Exame()
    Gtk.main()