import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk


class Exame(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Exame 15-12-2018")
        self.set_border_width(10)
        caixaPrincipal = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add(caixaPrincipal)

        boxH = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing= 1)
        caixaPrincipal.pack_start(boxH, False, False, 2)


        caixaH1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing= 1)
        imaxe = Gtk.Image()
        imaxe.set_from_icon_name("media-optical", Gtk.IconSize.DIALOG)
        chkAnimado = Gtk.CheckButton(label="Animado")

        boxH.pack_start(caixaH1,False,False,2)
        caixaH1.pack_start(imaxe, False, False, 2)
        caixaH1.pack_start(chkAnimado, False, False, 2)

        caixaH2 = Gtk.Box(orientation = Gtk.Orientation.VERTICAL, spacing=1)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.ALWAYS)

        tvwTaboa = Gtk.TextView()
        tvwTaboa.set_size_request(400, 1000)
        scroll.add(tvwTaboa)


        boxH.pack_start(caixaH2, True, False, 2)
        caixaH2.pack_start(scroll, True, False, 2)



        caixaH3 = Gtk.Box(orientation = Gtk.Orientation.VERTICAL, spacing=1)
        btnReproducir = Gtk.Button(label="Engadir a pista a reproducir")
        btnPausa = Gtk.Button(label="Subir na lista")
        btnParar = Gtk.Button(label="Baixar na lista")
        btnSaltar = Gtk.Button(label="Saltar")

        caixa4 = Gtk.Box(orientation = Gtk.Orientation.HORIZONTAL, spacing=1)
        cmbPosicionSaltar = Gtk.ComboBoxText()
        cmbPosicionSaltar.set_size_request(140, 10)
        cmbPosicionSaltar.append_text("Inicio")
        cmbPosicionSaltar.append_text("Fin")
        cmbPosicionSaltar.append_text("Anterior")
        cmbPosicionSaltar.append_text("Seguinte")
        caixaH3.pack_start(caixa4,False,False,2)
        caixa4.pack_start(btnSaltar, False, False, 2)
        caixa4.pack_start(cmbPosicionSaltar, False, False, 2)

        btnAbrirFicheiro = Gtk.Button(label="Abrir ficheiro...")
        btnFalarFicheiro = Gtk.Button(label="Reproducir ficheiro...")
        btnGardarComo = Gtk.Button(label="Gardar como...")
        btnEliminar = Gtk.Button(label="Eliminar pista")

        boxH.pack_start(caixaH3, False, False, 2)
        caixaH3.pack_start(btnReproducir, False, False, 2)
        caixaH3.pack_start(btnPausa, False, False, 2)
        caixaH3.pack_start(btnParar, False, False, 2)
   #     caixaH3.pack_start(btnSaltar, False, False, 2)
   #     caixaH3.pack_start(cmbPosicionSaltar, False, False, 2)
        caixaH3.pack_start(btnAbrirFicheiro, False, False, 2)
        caixaH3.pack_start(btnFalarFicheiro, False, False, 2)
        caixaH3.pack_start(btnGardarComo, False, False, 2)
        caixaH3.pack_start(btnEliminar, False, False, 2)

     #   imaxe = Gtk.Image()
     #   imaxe.set_from_icon_name("media-optical", Gtk.IconSize.DIALOG)
     #   chkAnimado = Gtk.CheckButton(label="Animado")
     #    tvwTaboa = Gtk.TreeView()
     #  tvwTaboa.set_size_request(420, 100)
     #   btnReproducir = Gtk.Button(label="Engadir a pista a reproducir")
     #   btnPausa = Gtk.Button(label="Subir na lista")
     #   btnParar = Gtk.Button(label="Baixar na lista")
     #   btnSaltar = Gtk.Button(label="Saltar")
     #   cmbPosicionSaltar = Gtk.ComboBoxText()
     #   cmbPosicionSaltar.set_size_request(140, 10)
     #   btnAbrirFicheiro = Gtk.Button(label="Abrir ficheiro...")
     #   btnFalarFicheiro = Gtk.Button(label="Reproducir ficheiro...")
     #   btnGardarComo = Gtk.Button(label="Gardar como...")
     #   btnEliminar = Gtk.Button(label="Eliminar pista")

        boxH2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=1)
        caixaPrincipal.pack_start(boxH2, False, False, 2)

        builder = Gtk.Builder()
        builder.add_from_file("./cadroSonGlade.glade")
        caixaH5 = builder.get_object("ckbox")

        boxH2.add(caixaH5)

     #   caixaH6 = Gtk.Box(orientation = Gtk.Orientation.VERTICAL, spacing=1)
     #   contedorH2 = Gtk.Frame()
     #   contedorH2.set_label("Opcións de reproducción")
     #   chkAsincrono = Gtk.CheckButton(label="Asíncrono")
     #   chkENomeFicheiro = Gtk.CheckButton(label="É nome de ficheiro")
     #   chkXmlPersistente = Gtk.CheckButton(label="XML persistente")
     #   chkFiltrarAntesReproducir = Gtk.CheckButton(label="Filtrar antes de reproducir")
     #   chkExml = Gtk.CheckButton(label="É XML")
     #   chkReproduccionNpl = Gtk.CheckButton(label="Reproducción NPL")

     #   boxH2.pack_start(caixaH6, False, False, 2)
     #   caixaH6.pack_start(contedorH2, False, False, 2)
     #   caixaH6.pack_start(chkAsincrono, False, False, 2)
     #   caixaH6.pack_start(chkXmlPersistente, False, False, 2)
     #   caixaH6.pack_start(chkENomeFicheiro, False, False, 2)
     #   caixaH6.pack_start(chkFiltrarAntesReproducir, False, False, 2)
     #   caixaH6.pack_start(chkExml, False, False, 2)
     #   caixaH6.pack_start(chkReproduccionNpl, False, False, 2)

        self.connect("delete-event", Gtk.main_quit)
        self.show_all()






if __name__=="__main__":

    Exame()
    Gtk.main()